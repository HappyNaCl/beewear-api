package com.beewear.api.domain.entities.enums;

public enum Gender {
    MALE,
    FEMALE,
    UNISEX,
    UNSPECIFIED;
}
