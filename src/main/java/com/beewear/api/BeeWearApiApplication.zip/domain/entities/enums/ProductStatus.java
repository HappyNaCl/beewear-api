package com.beewear.api.domain.entities.enums;

public enum ProductStatus {
    ACTIVE,
    SOLD,
    INACTIVE
}
