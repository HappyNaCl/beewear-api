package com.beewear.api.domain.entities.enums;

public enum SubscriptionStatus {
    ACTIVE,
    INACTIVE,
    CANCELLED
}
