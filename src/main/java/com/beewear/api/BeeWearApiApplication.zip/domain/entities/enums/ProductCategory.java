package com.beewear.api.domain.entities.enums;

public enum ProductCategory {
    TOP,
    BOTTOM,
    SHOES,
    ACCESSORY,
}
