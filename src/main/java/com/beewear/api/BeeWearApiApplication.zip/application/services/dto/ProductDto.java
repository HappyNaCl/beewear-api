package com.beewear.api.application.services.dto;

import com.beewear.api.domain.entities.Product;
import com.beewear.api.domain.entities.enums.Gender;
import com.beewear.api.domain.entities.enums.ProductCategory;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
public class ProductDto {
    private UUID id;
    private String name;
    private Double price;
    private Gender forGender;
    private ProductCategory category;
    private String imageUrl;
    private Instant createdAt;

    public static ProductDto fromProduct(Product product) {
        ProductDto dto = new ProductDto();
        dto.id = product.getId();
        dto.name = product.getName();
        dto.price = product.getPrice();
        dto.forGender = product.getForGender();
        dto.category = product.getProductCategory();
        dto.imageUrl = product.getProductImages().get(0).getImageUrl();
        dto.createdAt = product.getCreatedAt();
        return dto;
    }
}
