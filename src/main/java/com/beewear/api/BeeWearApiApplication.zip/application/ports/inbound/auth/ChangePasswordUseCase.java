package com.beewear.api.application.ports.inbound.auth;

public interface ChangePasswordUseCase {
}
