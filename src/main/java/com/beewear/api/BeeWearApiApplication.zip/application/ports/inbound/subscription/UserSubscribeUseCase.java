package com.beewear.api.application.ports.inbound.subscription;

public interface UserSubscribeUseCase {
    void subscribeUser();
}
